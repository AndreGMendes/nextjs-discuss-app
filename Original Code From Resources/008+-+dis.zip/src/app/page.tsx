import { Button } from '@nextui-org/react';

export default function Home() {
  return (
    <div>
      <Button>Click me!!!</Button>
    </div>
  );
}
